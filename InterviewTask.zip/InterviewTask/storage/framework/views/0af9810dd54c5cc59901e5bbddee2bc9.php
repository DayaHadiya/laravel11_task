<script src="<?php echo e(asset('js/jquery-3.7.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-select.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/custom.js')); ?>"></script>

<script type="text/javascript">
  $(document).ready(function () {
    $(".selectMonth").selectpicker();
  });
</script>
<?php /**PATH C:\xampp\htdocs\InterviewTask\resources\views/include/footer.blade.php ENDPATH**/ ?>