<!DOCTYPE html>
<html>
<head>
	<title>OTP</title>
</head>
<body>
	<p><?php echo e($name); ?> Your Verification Code is <b><?php echo e($otp); ?></b></p>
</body>
</html><?php /**PATH C:\xampp\htdocs\InterviewTask\resources\views/otpemail.blade.php ENDPATH**/ ?>