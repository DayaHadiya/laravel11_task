<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>OTP</title>
      <link rel="shortcut icon" href="<?php echo e(asset('image/favicon.ico')); ?>" type="image/x-icon">
      <link rel="icon" href="<?php echo e(asset('image/favicon.ico')); ?>" type="image/x-icon">
      <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
   </head>
   <body>
      <div class="login-page-main login-bg">
         <div class="login-box-wrap">
            <div class="login-top d-flex justify-content-between">
               <div class="login-logo">
                  <a class="side-logo" href="#" title="Multichoice - Enriching Lives">
                  <img src="<?php echo e(asset('images/logo.png')); ?>" width="120" height="73" alt="Multichoice Logo" />
                  </a>
               </div>
               <div class="support-mail text-end">
                  <p class="text-rg font-14 text--white">Need help? Email us at <a href="mailto:support@email.co.za" class="text-bd text--white">support@email.co.za</a></p>
               </div>
            </div>
            <div class="login-box">
               <div class="login-box-inner">
                  <?php if(!empty($errorMsg)): ?>
                    <div class="text-center alert alert-danger"> <?php echo e($errorMsg); ?></div>
                  <?php endif; ?>
                  <h2 class="font-22 text-center text--white mb-3">Enter OTP</h2>
                  <div class="text-center">
                     <p class="font-14 text-md text-center text--white mb-4">We have sent you an email with a OTP Pin. </p>
                  </div>
                  <form action="otp" method="post">
                     <?php echo csrf_field(); ?>
                     <input type="hidden" name="userotp" value="<?php echo e($otp); ?>">
                     <div class="form-group">
                        <label for="numberotp" class="text--white font-14">Enter OTP</label>
                        <input type="number" class="form-control otp-input-fields" placeholder="" id="numberotp" name="otp" required>
                     </div>
                     <div class="mt-4 pb-2 text-center">
                        <button type="submit" class="bttn bttn-primary">Submit</button>    
                     </div>
                     <div class="mt-4 text-center">
                        <a href="#" class="text--white text text-decoration-underline font-14">Resend OTP</a>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <script src="<?php echo e(asset('js/jquery-3.7.1.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
   </body>
</html><?php /**PATH C:\xampp\htdocs\InterviewTask\resources\views/otp.blade.php ENDPATH**/ ?>