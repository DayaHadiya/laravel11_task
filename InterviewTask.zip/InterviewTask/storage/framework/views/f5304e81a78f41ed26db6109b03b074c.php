<!DOCTYPE html>
<html lang="en-US">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Sign In</title>
      <link rel="shortcut icon" href="<?php echo e(asset('image/favicon.ico')); ?>" type="image/x-icon">
      <link rel="icon" href="<?php echo e(asset('image/favicon.ico')); ?>" type="image/x-icon">
      <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
      <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
   </head>
   <body>
      <div class="login-page-main login-bg">
         <div class="login-box-wrap">
            <div class="login-top d-flex justify-content-between">
               <div class="login-logo">
                  <a class="side-logo" href="#" title="Multichoice - Enriching Lives">
                  <img src="<?php echo e(asset('images/logo.png')); ?>" width="120" height="73" alt="Multichoice Logo" />
                  </a>
               </div>
               <div class="support-mail text-end">
                  <p class="text-rg font-14 text--white">Need help? Email us at <a href="mailto:support@email.co.za" class="text-bd text--white">support@email.co.za</a></p>
               </div>
            </div>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="login-box">
               <div class="login-box-inner">
                <?php if(!empty($errorMsg)): ?>
                    <div class="text-center alert alert-danger"> <?php echo e($errorMsg); ?></div>
                <?php endif; ?>
                  <h2 class="font-22 text-center text--white mb-3">Sign in</h2>
                  <form action="<?php echo e(route('loginsubmit')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                     <div class="form-group">
                        <label for="email" class="text--white font-14">Email</label>
                        <input type="email" class="form-control" placeholder="" id="email" name="email" required>
                     </div>
                     <div class="form-group">
                        <label for="pwd" class="text--white font-14">Password</label>
                        <input type="password" class="form-control" placeholder="" id="pwd" name="password" required>
                        <div class="mt-2 text-end">
                           <a href="#" class="text--white text text-decoration-underline font-12">Forgot Password</a>
                        </div>
                     </div>
                     <div class="mt-4 pb-2 text-center">
                        <button type="submit" class="bttn bttn-primary">Sign In</button>    
                     </div>
                     <div class="mt-4 text-center">
                        <a href="#" class="text--white text text-decoration-underline font-14">Single Sign-On</a>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      </div>
      <script src="<?php echo e(asset('js/jquery-3.7.1.min.js')); ?>"></script>
      <script src="<?php echo e(asset('js/custom.js')); ?>"></script>
   </body>
</html><?php /**PATH C:\xampp\htdocs\InterviewTask\resources\views/login.blade.php ENDPATH**/ ?>