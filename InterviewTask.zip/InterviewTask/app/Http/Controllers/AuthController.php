<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Mail;

class AuthController extends Controller
{
    /**
     * Login The User
     * @param Request $request
     * @return User
     */

    public function login()
    {
       return view('login');
    }

    public function loginUser(Request $request)
    {

        try {
            $validated = $request->validate( 
            [
                'email' => 'required|email',
                'password' => 'required'
            ]);

            if(!Auth::attempt($request->only(['email', 'password']))){
                return view('login')->with('errorMsg','please enter valid email and password');
            }

            $user = User::where('email', $request->email)->first();

            $email = $user->email;
            $password = $user->password;
            $otp = rand ( 1000 , 9999 );
            $data = array('name'=>$user->name,'email'=>$user->email,'otp'=>$otp);
            $mails = array('email'=>$user->email,'password'=>$user->password);
            Mail::send('otpemail', $data,function($message) use ($mails) {
             $message->to($mails['email'])->subject
                ('Verification');
             $message->from('xyz@gmail.com','Verification');
            });
            User::where('email', $request->email)->update(['otp'=>$otp]);
            return view('otp',compact('otp'));

        } catch (\Throwable $th) {
            return response()->json([
                'status' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    public function otp(Request $request)
    {
        try 
        {
            $validated = $request->validate( 
            [
                'otp' => 'required',
            ]);

            $otp1 = $request->otp;
            $otp = $request->userotp;
            if($otp == $otp1)
            {
                return redirect()->route('dashboard');
            }
            else
            {
                return view('otp',compact('otp'))->with('errorMsg','Please enter valid otp');
            }
        } catch (Exception $e) {
            
        }
    }

    public function dashboard()
    {
        return view('dashboard');
    }

    public function logout(Request $request)
    {
        Auth::guard('web')->logout();
        return redirect()->route('login');
    }

}