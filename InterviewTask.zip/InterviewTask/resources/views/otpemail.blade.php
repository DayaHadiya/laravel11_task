<!DOCTYPE html>
<html>
<head>
	<title>OTP</title>
</head>
<body>
	<p>{{$name}} Your Verification Code is <b>{{$otp}}</b></p>
</body>
</html>