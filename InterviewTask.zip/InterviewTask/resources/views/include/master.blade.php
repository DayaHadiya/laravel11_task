<!DOCTYPE html>
<html lang="en-US">
    @include('include.header')
    <body>
        @yield('content')

        @include('include.footer')
    </body>
</html>